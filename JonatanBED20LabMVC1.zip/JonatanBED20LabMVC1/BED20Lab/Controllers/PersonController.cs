﻿using Microsoft.AspNetCore.Mvc;
using BED20Lab.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BED20Lab.Controllers
{
    public class PersonController : Controller
    {
        //Get
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(PersonFormModel personFormModel)
        {
            ViewBag.Fname = personFormModel.Fname;
            return View(personFormModel);
        }
    }
}
