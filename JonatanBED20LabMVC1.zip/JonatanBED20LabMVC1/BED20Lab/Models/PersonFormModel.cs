﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BED20Lab.Models
{
    public class PersonFormModel
    {
        [Required]
        public string  Fname { get; set; }
        [Required]
        public int Age { get; set; }
        public bool IsSeahawkFan { get; set; }
    }
}
